<?php
/**
 * Plugin Name: ML Cursor MCP
 * Description: Minimal enabler for ML Cursor MCP Server v3.0.0
 * Version: 3.0.0
 * Author: ML Claude Team
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * 
 * This plugin is a minimal enabler for the ML Cursor MCP Server.
 * The MCP server talks directly to WordPress's built-in REST API.
 * This plugin just provides the one-click installer and Application Password support.
 */

if (!defined('ABSPATH')) {
    exit;
}

class MLCursorMCP_V3 {
    
    const VERSION = '3.0.0';
    
    public function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
    }
    
    public function admin_menu() {
        add_menu_page(
            'ML Cursor MCP',
            'ML Cursor MCP',
            'manage_options',
            'ml-cursor-mcp',
            array($this, 'admin_page'),
            'dashicons-admin-tools',
            80
        );
    }
    
    public function admin_init() {
        // Ensure Application Passwords are enabled
        add_filter('wp_is_application_passwords_available', '__return_true');
    }
    
    public function admin_page() {
        $current_user = wp_get_current_user();
        ?>
        <div class="wrap">
            <h1>ML Cursor MCP v<?php echo self::VERSION; ?></h1>
            
            <div style="background: #f0f6fc; border: 2px solid #0969da; border-radius: 6px; padding: 20px; margin: 20px 0;">
                <h2 style="margin-top: 0;">🚀 Three Simple Steps</h2>
                
                <!-- Step 1: Create Application Password -->
                <div style="margin-bottom: 25px;">
                    <h3>Step 1: Create Application Password</h3>
                    <p>Go to: <strong>Users → Profile → Application Passwords</strong></p>
                    <ol>
                        <li>Enter a name: <code>ML Cursor MCP</code></li>
                        <li>Click "Add New Application Password"</li>
                        <li>Copy the generated password (format: <code>xxxx xxxx xxxx xxxx</code>)</li>
                    </ol>
                    <p><a href="<?php echo admin_url('profile.php#application-passwords-section'); ?>" class="button button-primary" target="_blank">→ Go to Application Passwords</a></p>
                </div>
                
                <!-- Step 2: Configure Cursor -->
                <div style="margin-bottom: 25px;">
                    <h3>Step 2: Add This Configuration to Cursor</h3>
                    <p class="description">Copy this config and paste into Cursor's MCP settings:</p>
                    
                    <?php
                    // Generate site-specific MCP name
                    $site_url = home_url();
                    $domain = parse_url($site_url, PHP_URL_HOST);
                    $domain_parts = explode('.', $domain);
                    array_pop($domain_parts); // Remove TLD
                    $domain_base = implode('', $domain_parts);
                    $domain_short = substr($domain_base, -10);
                    $mcp_name = 'ml-cursor-' . $domain_short;
                    
                    $config = array(
                        'mcpServers' => array(
                            $mcp_name => array(
                                'command' => 'npx',
                                'args' => array('-y', 'github:wplaunchify/ml-wp-bridge'),
                                'env' => array(
                                    'WP_URL' => $site_url,
                                    'WP_USERNAME' => $current_user->user_login,
                                    'WP_PASSWORD' => 'YOUR_APPLICATION_PASSWORD_HERE'
                                )
                            )
                        )
                    );
                    $config_json = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
                    ?>
                    
                    <div style="position: relative;">
                        <pre style="background: #1e1e1e; color: #d4d4d4; padding: 15px; border-radius: 4px; overflow-x: auto; font-size: 13px; line-height: 1.5;"><code><?php echo esc_html($config_json); ?></code></pre>
                        <button onclick="copyConfig()" class="button button-secondary" style="position: absolute; top: 10px; right: 10px;">📋 Copy</button>
                    </div>
                    
                    <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 10px 15px; margin-top: 15px;">
                        <p style="margin: 0;"><strong>⚠️ Important:</strong> Replace <code>YOUR_APPLICATION_PASSWORD_HERE</code> with the Application Password you created in Step 1!</p>
                    </div>
                    
                    <p class="description" style="margin-top: 15px;"><strong>Where to paste:</strong></p>
                    <ol style="margin-left: 20px; line-height: 1.8;">
                        <li>Open Cursor IDE</li>
                        <li>Go to: <strong>Settings → Features → Model Context Protocol</strong></li>
                        <li>Click <strong>"Edit Config"</strong> (opens mcp.json)</li>
                        <li>Paste this configuration</li>
                        <li>Replace <code>YOUR_APPLICATION_PASSWORD_HERE</code> with your actual password</li>
                        <li>Save the file</li>
                    </ol>
                </div>
                
                <!-- Step 3: Restart -->
                <div>
                    <h3>Step 3: Restart Cursor</h3>
                    <p>Close and reopen Cursor IDE. When it starts, it will automatically download the MCP server from GitHub.</p>
                    <p><strong>Test it:</strong> Ask Cursor to "List all posts" or "Show me all pages"</p>
                    <p style="color: #28a745;"><strong>✅ All WordPress tools will be available!</strong></p>
                </div>
            </div>
            
            <!-- Info Panel -->
            <div style="background: white; padding: 20px; margin: 20px 0; border: 1px solid #ddd; border-radius: 4px;">
                <h2>📋 What This Plugin Does</h2>
                <p>This is a <strong>minimal enabler</strong> for the ML Cursor MCP Server v3.0.0:</p>
                <ul>
                    <li>✅ Enables Application Password support</li>
                    <li>✅ Provides one-click configuration generator</li>
                    <li>✅ Shows installation instructions</li>
                </ul>
                <p><strong>The MCP server talks directly to WordPress's built-in REST API</strong> - no custom endpoints needed!</p>
                
                <h3>Available Tools</h3>
                <p>The MCP server provides <strong>35+ WordPress management tools</strong>:</p>
                <ul style="columns: 2;">
                    <li>Posts (5 tools)</li>
                    <li>Pages (5 tools)</li>
                    <li>Media (5 tools)</li>
                    <li>Users (5 tools)</li>
                    <li>Categories (5 tools)</li>
                    <li>Tags (5 tools)</li>
                    <li>Comments (5 tools)</li>
                </ul>
            </div>
            
            <!-- System Info -->
            <div style="background: white; padding: 20px; margin: 20px 0; border: 1px solid #ddd; border-radius: 4px;">
                <h2>ℹ️ System Information</h2>
                <table class="widefat">
                    <tr>
                        <td><strong>Plugin Version:</strong></td>
                        <td><?php echo self::VERSION; ?></td>
                    </tr>
                    <tr>
                        <td><strong>WordPress Version:</strong></td>
                        <td><?php echo get_bloginfo('version'); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Site URL:</strong></td>
                        <td><?php echo home_url(); ?></td>
                    </tr>
                    <tr>
                        <td><strong>REST API:</strong></td>
                        <td><?php echo rest_url(); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Current User:</strong></td>
                        <td><?php echo $current_user->user_login; ?> (<?php echo $current_user->user_email; ?>)</td>
                    </tr>
                    <tr>
                        <td><strong>Application Passwords:</strong></td>
                        <td><?php echo wp_is_application_passwords_available() ? '✅ Enabled' : '❌ Disabled'; ?></td>
                    </tr>
                </table>
            </div>
        </div>
        
        <script>
        function copyConfig() {
            var config = <?php echo $config_json; ?>;
            var configText = JSON.stringify(config, null, 2);
            
            navigator.clipboard.writeText(configText).then(function() {
                alert('✅ Configuration copied to clipboard!\n\nDon\'t forget to replace YOUR_APPLICATION_PASSWORD_HERE with your actual Application Password!');
            }).catch(function(err) {
                alert('Failed to copy: ' + err.message);
            });
        }
        </script>
        <?php
    }
}

// Initialize plugin
new MLCursorMCP_V3();

