<?php
/**
 * Plugin Name: ML Cursor MCP
 * Description: Minimal enabler for ML Cursor MCP Server v3.1.0
 * Version: 3.1.0
 * Author: ML Claude Team
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * 
 * This plugin is a minimal enabler for the ML Cursor MCP Server.
 * The MCP server talks directly to WordPress's built-in REST API.
 * This plugin just provides the one-click installer and Application Password support.
 */

if (!defined('ABSPATH')) {
    exit;
}

class MLCursorMCP_V3 {
    
    const VERSION = '3.1.0';
    
    public function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
    }
    
    public function admin_menu() {
        add_menu_page(
            'ML Cursor MCP',
            'ML Cursor MCP',
            'manage_options',
            'ml-cursor-mcp',
            array($this, 'admin_page'),
            'dashicons-admin-tools',
            80
        );
    }
    
    public function admin_init() {
        // Ensure Application Passwords are enabled
        add_filter('wp_is_application_passwords_available', '__return_true');
        
        // Handle AJAX request to generate Application Password
        add_action('wp_ajax_ml_cursor_generate_password', array($this, 'ajax_generate_password'));
    }
    
    /**
     * Generate Application Password via AJAX
     */
    public function ajax_generate_password() {
        check_ajax_referer('ml_cursor_generate_password', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $user_id = get_current_user_id();
        $app_name = 'ML Cursor MCP - ' . date('Y-m-d H:i:s');
        
        // Create Application Password
        $created = WP_Application_Passwords::create_new_application_password($user_id, array(
            'name' => $app_name,
        ));
        
        if (is_wp_error($created)) {
            wp_send_json_error($created->get_error_message());
        }
        
        // Return the password (only time it's available!)
        wp_send_json_success(array(
            'password' => WP_Application_Passwords::chunk_password($created[0]),
            'name' => $app_name,
        ));
    }
    
    public function admin_page() {
        $current_user = wp_get_current_user();
        ?>
        <div class="wrap">
            <h1>ML Cursor MCP v<?php echo self::VERSION; ?></h1>
            
            <div style="background: #f0f6fc; border: 2px solid #0969da; border-radius: 6px; padding: 20px; margin: 20px 0;">
                <h2 style="margin-top: 0;">🚀 Two Simple Steps</h2>
                
                <!-- Step 1: Generate Config -->
                <div style="margin-bottom: 25px;">
                    <h3>Step 1: Get Your Configuration</h3>
                    <p>Choose your preferred method:</p>
                    
                    <div style="display: flex; gap: 10px; margin: 15px 0;">
                        <button onclick="showPreview()" class="button button-secondary button-large">
                            👁️ Show Configuration Preview
                        </button>
                        <button onclick="generateConfig()" class="button button-primary button-large">
                            🔑 Generate with Auto-Password (One-Click)
                        </button>
                    </div>
                    
                    <div id="config-loading" style="display: none; margin: 15px 0;">
                        <p style="color: #0969da;">⏳ Generating Application Password and configuration...</p>
                    </div>
                    
                    <!-- Preview Mode -->
                    <div id="config-preview" style="display: none; margin-top: 20px;">
                        <p class="description"><strong>📋 Configuration Preview</strong> (You'll need to create an Application Password manually):</p>
                        
                        <div style="position: relative;">
                            <pre id="preview-display" style="background: #1e1e1e; color: #d4d4d4; padding: 15px; border-radius: 4px; overflow-x: auto; font-size: 13px; line-height: 1.5;"><code></code></pre>
                            <button onclick="copyPreview()" class="button button-secondary" style="position: absolute; top: 10px; right: 10px;">📋 Copy</button>
                        </div>
                        
                        <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 10px 15px; margin-top: 15px;">
                            <p style="margin: 0;"><strong>⚠️ Manual Setup Required:</strong></p>
                            <ol style="margin: 10px 0 0 20px; line-height: 1.6;">
                                <li>Go to: <a href="<?php echo admin_url('profile.php#application-passwords-section'); ?>" target="_blank">Users → Profile → Application Passwords</a></li>
                                <li>Create a new Application Password named "ML Cursor MCP"</li>
                                <li>Copy the generated password</li>
                                <li>Replace <code>YOUR_APPLICATION_PASSWORD_HERE</code> in the config above</li>
                            </ol>
                        </div>
                    </div>
                    
                    <!-- Auto-Generated Mode -->
                    <div id="config-container" style="display: none; margin-top: 20px;">
                        <p class="description"><strong>✅ Configuration ready!</strong> Copy this and paste into Cursor's MCP settings:</p>
                        
                        <div style="position: relative;">
                            <pre id="config-display" style="background: #1e1e1e; color: #d4d4d4; padding: 15px; border-radius: 4px; overflow-x: auto; font-size: 13px; line-height: 1.5;"><code></code></pre>
                            <button onclick="copyGeneratedConfig()" class="button button-secondary" style="position: absolute; top: 10px; right: 10px;">📋 Copy</button>
                        </div>
                        
                        <div style="background: #d1ecf1; border-left: 4px solid #0c5460; padding: 10px 15px; margin-top: 15px;">
                            <p style="margin: 0;"><strong>✅ Application Password created:</strong> <code id="app-password-display"></code></p>
                            <p style="margin: 5px 0 0 0; font-size: 12px;">This password is already included in the config above. Save it if you need it later!</p>
                        </div>
                    </div>
                    
                    <!-- Common Instructions -->
                    <div id="paste-instructions" style="display: none; margin-top: 20px;">
                        <p class="description"><strong>Where to paste:</strong></p>
                        <ol style="margin-left: 20px; line-height: 1.8;">
                            <li>Open Cursor IDE</li>
                            <li>Go to: <strong>Settings → Features → Model Context Protocol</strong></li>
                            <li>Click <strong>"Edit Config"</strong> (opens mcp.json)</li>
                            <li>Paste the configuration above</li>
                            <li>Save the file</li>
                        </ol>
                    </div>
                </div>
                
                <!-- Step 2: Restart -->
                <div>
                    <h3>Step 2: Restart Cursor</h3>
                    <p>Close and reopen Cursor IDE. When it starts, it will automatically download the MCP server from GitHub.</p>
                    <p><strong>Test it:</strong> Ask Cursor to "List all posts" or "Show me all pages"</p>
                    <p style="color: #28a745;"><strong>✅ All WordPress tools will be available!</strong></p>
                </div>
            </div>
            
            <!-- Info Panel -->
            <div style="background: white; padding: 20px; margin: 20px 0; border: 1px solid #ddd; border-radius: 4px;">
                <h2>📋 What This Plugin Does</h2>
                <p>This is a <strong>minimal enabler</strong> for the ML Cursor MCP Server v3.1.0:</p>
                <ul>
                    <li>✅ Enables Application Password support</li>
                    <li>✅ Provides one-click configuration generator</li>
                    <li>✅ Shows installation instructions</li>
                </ul>
                <p><strong>The MCP server talks directly to WordPress's built-in REST API</strong> - no custom endpoints needed!</p>
                
                <h3>Available Tools</h3>
                <p>The MCP server provides <strong>35+ WordPress management tools</strong>:</p>
                <ul style="columns: 2;">
                    <li>Posts (5 tools)</li>
                    <li>Pages (5 tools)</li>
                    <li>Media (5 tools)</li>
                    <li>Users (5 tools)</li>
                    <li>Categories (5 tools)</li>
                    <li>Tags (5 tools)</li>
                    <li>Comments (5 tools)</li>
                </ul>
            </div>
            
            <!-- System Info -->
            <div style="background: white; padding: 20px; margin: 20px 0; border: 1px solid #ddd; border-radius: 4px;">
                <h2>ℹ️ System Information</h2>
                <table class="widefat">
                    <tr>
                        <td><strong>Plugin Version:</strong></td>
                        <td><?php echo self::VERSION; ?></td>
                    </tr>
                    <tr>
                        <td><strong>WordPress Version:</strong></td>
                        <td><?php echo get_bloginfo('version'); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Site URL:</strong></td>
                        <td><?php echo home_url(); ?></td>
                    </tr>
                    <tr>
                        <td><strong>REST API:</strong></td>
                        <td><?php echo rest_url(); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Current User:</strong></td>
                        <td><?php echo $current_user->user_login; ?> (<?php echo $current_user->user_email; ?>)</td>
                    </tr>
                    <tr>
                        <td><strong>Application Passwords:</strong></td>
                        <td><?php echo wp_is_application_passwords_available() ? '✅ Enabled' : '❌ Disabled'; ?></td>
                    </tr>
                </table>
            </div>
        </div>
        
        <script>
        var generatedConfig = null;
        var previewConfig = null;
        
        // Common config builder
        function buildConfig(password) {
            var siteUrl = '<?php echo home_url(); ?>';
            var username = '<?php echo $current_user->user_login; ?>';
            var domain = siteUrl.replace(/^https?:\/\//, '').replace(/\/$/, '');
            var domainParts = domain.split('.');
            var siteName = domainParts[0]; // Just use first part (e.g., "newmlcursor")
            var mcpName = 'ml-cursor-' + siteName;
            
            var config = {
                mcpServers: {}
            };
            config.mcpServers[mcpName] = {
                command: 'npx',
                args: ['-y', 'github:wplaunchify/ml-wp-bridge'],
                env: {
                    WP_URL: siteUrl,
                    WP_USERNAME: username,
                    WP_PASSWORD: password
                }
            };
            
            return config;
        }
        
        // Show preview with placeholder
        function showPreview() {
            // Hide other sections
            document.getElementById('config-loading').style.display = 'none';
            document.getElementById('config-container').style.display = 'none';
            
            // Build preview config
            previewConfig = buildConfig('YOUR_APPLICATION_PASSWORD_HERE');
            var configJson = JSON.stringify(previewConfig, null, 2);
            document.querySelector('#preview-display code').textContent = configJson;
            
            // Show preview
            document.getElementById('config-preview').style.display = 'block';
            document.getElementById('paste-instructions').style.display = 'block';
        }
        
        // Copy preview
        function copyPreview() {
            if (!previewConfig) {
                alert('Please show preview first!');
                return;
            }
            
            var configText = JSON.stringify(previewConfig, null, 2);
            
            navigator.clipboard.writeText(configText).then(function() {
                alert('✅ Configuration copied to clipboard!\n\n⚠️ Don\'t forget to:\n1. Create an Application Password\n2. Replace YOUR_APPLICATION_PASSWORD_HERE with your actual password!');
            }).catch(function(err) {
                alert('Failed to copy: ' + err.message);
            });
        }
        
        // Generate with auto-password
        function generateConfig() {
            // Hide other sections
            document.getElementById('config-preview').style.display = 'none';
            
            // Show loading
            document.getElementById('config-loading').style.display = 'block';
            document.getElementById('config-container').style.display = 'none';
            
            // Make AJAX request to generate Application Password
            jQuery.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'ml_cursor_generate_password',
                    nonce: '<?php echo wp_create_nonce('ml_cursor_generate_password'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        var password = response.data.password;
                        
                        // Build complete config with real password
                        generatedConfig = buildConfig(password);
                        
                        // Display config
                        var configJson = JSON.stringify(generatedConfig, null, 2);
                        document.querySelector('#config-display code').textContent = configJson;
                        document.getElementById('app-password-display').textContent = password;
                        
                        // Hide loading, show config
                        document.getElementById('config-loading').style.display = 'none';
                        document.getElementById('config-container').style.display = 'block';
                        document.getElementById('paste-instructions').style.display = 'block';
                    } else {
                        alert('Error: ' + response.data);
                        document.getElementById('config-loading').style.display = 'none';
                    }
                },
                error: function(xhr, status, error) {
                    alert('Error generating configuration: ' + error);
                    document.getElementById('config-loading').style.display = 'none';
                }
            });
        }
        
        // Copy generated config
        function copyGeneratedConfig() {
            if (!generatedConfig) {
                alert('Please generate configuration first!');
                return;
            }
            
            var configText = JSON.stringify(generatedConfig, null, 2);
            
            navigator.clipboard.writeText(configText).then(function() {
                alert('✅ Configuration copied to clipboard!\n\nPaste it into Cursor\'s mcp.json and restart Cursor!');
            }).catch(function(err) {
                alert('Failed to copy: ' + err.message);
            });
        }
        </script>
        <?php
    }
}

// Initialize plugin
new MLCursorMCP_V3();

